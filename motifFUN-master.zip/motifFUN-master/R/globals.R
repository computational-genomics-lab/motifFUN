utils::globalVariables(c("input_file", "position", "bits", "element", "mafft.out.name", "aes"))
